<?php

const BASEDIR= 'C:\xampp\htdocs\patika\todo_app';
const URL= 'http://localhost/patika/todo_app/';
const DEV_MODE = true;


//config her sayfada var her yerden db degıskenıne erısılebılır bu yuzden
try {
    $db = new PDO('mysql:host=localhost;dbname=todoapp;', 'root', '');
}catch (PDOException $e){
    echo $e->getMessage();
}