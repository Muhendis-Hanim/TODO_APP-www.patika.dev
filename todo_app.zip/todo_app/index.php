<?php
session_start();
require __DIR__.'/config/config.php';

if (DEV_MODE == true){  //developer moddaysak hataları gosterecek degılsek gostermeyecek
    error_reporting(E_ALL);
    ini_set('error_reporting',true);    //hata gosterımı aktıf degılse aktıf eder ama bzıımkı zaten aktıftı

}else{
    error_reporting(0);
    ini_set('error_reporting',false);
}


#butun helpers içindeki php dosyalarını bu sekılde dahıl etmıs olduk
foreach (glob(BASEDIR.'/helpers/*.php') as $file){
    require $file;
}

$config['route'][0] = 'home';
$config['lang'] = 'tr';

if (isset($_GET['route'])) {
    // "/" a kadar kı kısım a dan z ye harfler iki karakter olabilir dil kısmı demek 2. ıkıncı kısım route ıcın
    preg_match('@(?<lang>\b[a-z]{2}\b)?/?(?<route>.*)/?@', $_GET['route'], $result);
    // print_r($result);

//Array ( [0] => en/home [1] => en [2] => home ) = cıktı bu oluyor. parametrelerı ayırıyor
//trabzon yazarsak array bos doner bunun onune gecmek lazım bunun ıcın "\b ıcıne alıcaz"
//aralardakı ?/? işareti olsa da olur olmasa da olur demek
//en sona / koyulursa url kısmına onu ekarte etmek ıcın sona da ?/ koyduk cok onelı degıl ama

    #Dil yapısını ayarladık asagıda
    if (isset($result['lang'])) {
        if (file_exists(__DIR__ . '/language/' . $result['lang'] . '.php')) {
            //gıdıp bakıcak dır altında language klasoru altında tr varmı dıye yanı bır dıl secımı varsa lang doysaı gelecek yoksa gelmeyecek

            $config['lang'] = $result['lang'];
        } else {
            $config['lang'] = 'tr';
        }


    }
}

if (isset($result['route'])){
    $config['route'] = explode('/', $result['route']); // "/ tan parcaladık" bırıncı ıkıncı parametre olarak ayrır ıste

}


require BASEDIR .'/language/' .$config['lang']. '.php';  //sayfaya dahil ettik
//echo $lang['title'];


if (file_exists(BASEDIR.'/Controller/'.$config['route'][0].'.php')){    //0. indis controllerımızı temsil edicek
    require BASEDIR.'/Controller/'.$config['route'][0].'.php';   //varsa bu yoldakı sayfayı ac
}else{
    echo 'Sayfa Bulunamadı..';
}

if (isset($_SESSION['error']))  $_SESSION['error']= null;   //session error varsa gerı geldıgımızde sıfırlansın dıye sesssion erroru null yap dedik
if (isset($_SESSION['post']))  $_SESSION['post']= null;     //post verılerını sıfıra cektık en sonunda

