<?php
session_destroy();
redirect('login');