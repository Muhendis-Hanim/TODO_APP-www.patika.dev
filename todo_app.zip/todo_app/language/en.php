 <?php
 $lang= [
     'title' => 'Title',
     'Oturum Açın' => 'Login',
     'E-Posta' =>'E-Mail',
     'Şifreniz' => 'Password',
     'Giriş Yap' => 'Sign in'

 ];