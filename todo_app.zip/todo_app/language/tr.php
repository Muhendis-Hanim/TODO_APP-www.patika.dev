<?php
$lang= [
    'title' => 'Başlik',
    'Oturum Açın' => 'Oturum Açın'
];